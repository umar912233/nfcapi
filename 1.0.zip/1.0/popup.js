// var css = '';
// var javascript = '';

// function addstyle(css, javascript) {
//     chrome.runtime.sendMessage({
//         command: 'addGHLstyle',
//         css:css,
//         javascript:javascript
//     });
// }

// function applyStyle(event) {
//     try {
//         var csschanged = '';
//         csschanged = css;
//         $(".dycontrol").each(function() {

//             if($(this).prop('type') == "checkbox")
//             {
//                 var checked = $(this).is(':checked') ? "true" : "false";

//                 if(csschanged != null){
//                     csschanged = csschanged.replaceAll($(this).attr("id"), checked);
//                 }
//             }          
//             else{

//                 if(csschanged != null){
//                     csschanged = csschanged.replaceAll($(this).attr("id"), $(this).val());
//                 }
//             }
//         });

//         if(csschanged != null){
//             csschanged = csschanged.replaceAll("\\", "\\\\");
//         }

//         chrome.runtime.sendMessage({
//             command: 'applystyle',
//             css:csschanged
//         });


//     } catch (e) {
//         alert(e);
//     }
// }

// $('#btnApply').click(function () {
//     try {
//         $(".dycontrol").each(function() {

//             if($(this).prop('type') == "checkbox")
//             {
//                 var checked = $(this).is(':checked') ? "true" : "false";

//                 if(css != null){
//                     css = css.replaceAll($(this).attr("id"), checked);
//                 }
//                 if(javascript != null){
//                     javascript = javascript.replaceAll($(this).attr("id"), checked);
//                 }
//             }          
//             else{

//                 if($(this).attr("id") == '#ARRLOCATIONIDS#'){
//                     var locarray = $(this).val().split(",");
//                     var locarraystr = '';
//                     var arrayLength = locarray.length;

//                     if(arrayLength > 1){
//                         locarraystr = '[';
//                         for (var i = 0; i < arrayLength; i++) {
//                             locarraystr += '"'+locarray[i].trim()+'", '
//                         }
//                         locarraystr = locarraystr.slice(0, -2);
//                         locarraystr += ']';

//                     }else{
//                         locarraystr = '[]';
//                     }

//                     if(javascript != null){
//                         javascript = javascript.replaceAll($(this).attr("id"), locarraystr);
//                     }

//                 }else{

//                     if(css != null){
//                         css = css.replaceAll($(this).attr("id"), $(this).val());
//                     }
//                     if(javascript != null){
//                         javascript = javascript.replaceAll($(this).attr("id"), $(this).val());
//                     }
//                 }
//             }
//         });

//         if(css != null){
//             css = css.replaceAll("\\", "\\\\");
//         }

//         addstyle(css, javascript);
//     } catch (e) {
//         alert(e);
//     }
// })

// $('#btnGHLSettings').click(function () {
//     chrome.runtime.sendMessage({
//         command: 'GHLSettings'
//     });

// })
    
// $("#category").change(function(){
//     try {

//         $('#section').empty()
//             switch ($('#category').val()) {
//             case "Dashboard":
//                 $('#section').append(new Option('--Select--', 'Select'));
//                 $('#section').append(new Option('Check In Button', 'DSHSTYLBTN001'));
//                 $('#section').append(new Option('Main Header', 'DSHSTYLHDR002'));
//                 $('#section').append(new Option('Card Header', 'DSHSTYLCRD003'));
//                 $('#section').append(new Option('Loading Animation Color', 'DSHSTYLANI004'));
//                 $('#section').append(new Option('Dashboard Style 1', 'DSHTHEMES0005'));
//                 $('#section').append(new Option('Dashboard Style 2', 'DSHTHMSPR0006'));
//                 $('#section').append(new Option('Dashboard Style (Gradients)', 'DSHTHMSGPR007'));
//                 $('#section').append(new Option('Top Navigation Styling', 'DSHTOPNAV0008'));
//                 break;
//             case "Login":
//                 $('#section').append(new Option('--Select--', 'Select'));
//                 $('#section').append(new Option('Login Style 1', 'LOGINVONE0009'));
//                 $('#section').append(new Option('Login Style 2', 'LOGINVTWO0010'));
//                 $('#section').append(new Option('Login Style 3', 'LOGINVTHRE011')); 
//                 break;
//             case "Misc":
//                 $('#section').append(new Option('--Select--', 'Select'));
//                 $('#section').append(new Option('Hide Check In', 'CHKINHDBTN012'));
//                 $('#section').append(new Option('Rename Check In', 'CHKINREBTN013'));
//                 $('#section').append(new Option('White Logo', 'DSHLOGOWHT014'));
//                 $('#section').append(new Option('Rename Opportunities', 'EDTMENUNAM015'));
//                 $('#section').append(new Option('Stop Sidebar from Minimizing', 'NOTCOLLAPS016'));
//                 break;
//             case "Hacks":
//                 $('#section').append(new Option('--Select--', 'Select'));
//                 $('#section').append(new Option('Favicon', 'DSHFAVICON017'));
//                 $('#section').append(new Option('New Menu Link', 'CSTMNAVLNK018'));
//                 $('#section').append(new Option('New Menu Link (by Location)', 'CSTMNAVLOC019'));
//                 $('#section').append(new Option('New Menu Link (Pop-Up)', 'CSTMNAVMDL020'));
//                 $('#section').append(new Option('Logo by Location', 'LOGOBYLCTN021'));
//                 $('#section').append(new Option('Dashboard Theme New', 'DSHTHMSTR0022'));
//                 break; 
//             case "Select":
//                 $('#section').append(new Option('--Select--', 'Select'));
//                 break;
//         }

//     } catch (e) {

//     }
// });


// $("#section").change(function(){
//     try {
//         var section = $('#section').val();
//         chrome.runtime.sendMessage({
//             command: 'getsection',
//             section:section
//         });
    
//     } catch (e) {

//     }
// });

// function setPopup(request) {
//     try {
//         css = '';
//         javascript = '';
//         $("#controlsdiv").empty();
//         $("#description").empty();

//         css = request.design.design[0].css;
//         javascript = request.design.design[0].javascript;
//         $("#description").append($("<p />", {
//             text: request.design.design[0].description
//         }))

//         var controlsdiv = $("#controlsdiv");
//         var control = '';
//         $.each(request.design.tagdetails, function(index, tagdetail) {
           
//             if(tagdetail.control != 'hidden')
//             {
//                 control = "<div class='col-xs-12 m-sm text-right'><div class='col-xs-4'> <label>"+tagdetail.label+"</label></div>";

//                 switch (tagdetail.control) {
//                     case "color":
//                         control += "<div class='col-xs-4'><input type='color' class='dycontrol color' id="+tagdetail.tag+" value="+tagdetail.defaultvalue+"></div><div class='col-xs-4'></div></div>";
//                         //control += "<div class='col-xs-4'><input type='color' class='dycontrol color' id='bgcolor' value="+tagdetail.defaultvalue+"></div><div class='col-xs-4'></div></div>";
//                         break;
//                     case "text":
//                         control += "<div class='col-xs-8'><input type='text' class='dycontrol txtbx' id="+tagdetail.tag+" value="+tagdetail.defaultvalue+"></div></div>";
//                         break;
//                     case "check":
//                         control += "<div class='col-xs-2'><input type='checkbox' class='dycontrol chkbx' id="+tagdetail.tag+" checked="+tagdetail.defaultvalue+"></div><div class='col-xs-6'></div></div>";
//                         break;
//                     case "ddwn":
//                         //control += "<div class='col-xs-6'><select class='dycontrol ddwnd' id="+tagdetail.tag+">"+getIcons(request.icons)+"</select></div><div class='col-xs-2'><i class='icon-play'></i></div></div></div>";
//                         control += "<div class='col-xs-6'><select class='dycontrol ddwnd  iconselect' onchange='Changeclass' id="+tagdetail.tag+">"+ getIcons(request.icons)+"</select></div><div class='col-xs-2 text-left'><i id='iconimage' class='far fa-address-book'></div></div></div>";
//                         break;
//                     }
//             }
//             else{
//                 control = "<input type='hidden' class='dycontrol' id="+tagdetail.tag+" value="+generateRandomId()+"></input>";
//             }
                
//                 controlsdiv.append(control);
//         });
        

//     } catch (err) {alert(err);}
// }

// $('#bgcolor').on('change',
//     function() {
//         alert($(this).val());
//     }
// );

// function getIcon() {
   
//     var obj=document.getElementsByClassName("iconselect")[0];
//     if(typeof obj !== 'undefined'){
//         obj.addEventListener("change", Changeclass);
//     } 
    
//     var colors = document.getElementsByClassName("color");
//     for (var i = 0; i < colors.length; i++) {
//         colors[i].addEventListener("change", applyStyle, false);
//     }
// }
   
// function Changeclass()
// {
//     var x = document.getElementsByClassName("iconselect")[0].value;
//     var icon=document.getElementById("iconimage");
//     icon.className=x;   
// }

// function getIcons(icons) {
//     var iconsoptions = '';
//     $.each(icons, function(index, icon) {

//         iconsoptions += "<option value='"+icon.fontclass+"'>"+icon.name+"</option>";
//     });
//     return iconsoptions;
// }

// function generateRandomId() {
//     var length = 5;
//     var result           = '';
//     var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
//     var charactersLength = characters.length;
//     for ( var i = 0; i < length; i++ ) {
//       result += characters.charAt(Math.floor(Math.random() * 
//  charactersLength));
//    }
//    return result;
// }

// chrome.runtime.onMessage.addListener(
//     function (request, sender) {
//         var command = request.command;

//         if (command == 'showdata') {
//             setPopup(request);
//             getIcon();
//         } 
//     }
// );

// function validateLicense() {
//     try {
//         chrome.storage.local.get(['licence'],
//             function (data) {
//                 if (data.licence.email != '' && data.licence.password != '') {
//                     if ((data.licence.lastCheck + (5 * 60 * 1000)) < Date.now()) {
//                         chrome.runtime.sendMessage({
//                             command: 'validate',
//                             email: data.licence.email,
//                             password: data.licence.password,
//                         });
//                     }
//                 }
//             });
//     } catch (err) {}
// }

// validateLicense();