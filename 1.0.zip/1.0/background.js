var testMode = false;

function addGHLstyle(request) {
    try{       
        var css = request.css != null && request.css != 'NULL' ? request.css.replaceAll(/\r?\n|\r/g, ' ').replace (/(^")|("$)/g, '') : '';
        //var script = request.javascript != null && request.javascript != 'NULL'? request.javascript.replaceAll(/\r?\n|\r/g, ' ') : '';
        var script = '';
        if(request.javascript != null && request.javascript != 'NULL'){
            script = request.javascript.replaceAll(/\r?\n|\r/g, ' ');
            script = script.replaceAll(/'/g, "\\'");
            //script = script.replaceAll("'", "&quot");
        }else{
            script = '';
        }

        var code = "document.querySelector('[placeholder=\"Custom CSS\"]').value += '"+css+"';\
        document.querySelector('[placeholder=\"Custom CSS\"]').dispatchEvent(new Event(\"input\"));\
        document.querySelector('[placeholder=\"Custom Javascript\"]').value += '"+script+"';\
        document.querySelector('[placeholder=\"Custom Javascript\"]').dispatchEvent(new Event(\"input\"));\
        var form = document.querySelector('[data-vv-scope=\"form-1\"]');\
        form.querySelector('button[type=\"submit\"]').click();"

        chrome.tabs.executeScript({
            code: code
        }, (results) => {
            
        });
    }
    catch (e) {
        alert(e);
    }
}

function applyStyle(request) {
    try{       
        var css = request.css != null && request.css != 'NULL' ? request.css.replaceAll(/\r?\n|\r/g, ' ').replace (/(^")|("$)/g, '') : '';
        
        var code = "if(document.body.getElementsByTagName('style').length > 0){document.body.getElementsByTagName('style')[0].remove();}\
                    var style = document.createElement('style');\
                    style.setAttribute('id', 'custstyleapply');\
                    document.body.appendChild(style);\
                    style.type = 'text/css';\
                    style.appendChild(document.createTextNode('"+css+"'));"

        chrome.tabs.executeScript({
            code: code
        }, (results) => {
            
        });
    }
    catch (e) {
        alert(e);
    }
}

function openGHLSettings(request) {
    try{

            chrome.tabs.update({
                url: 'https://app.gohighlevel.com/settings/company'
            }, function () {
              
            });
    }
    catch (e) {
        alert(e);
    }
}

function getDesignData(section) {
    try {
        var token = 'af9c88b46b3c65751a61398bd2b65076';
        var url = 'http://159.65.213.76:5055/getdesigns';
        var data = JSON.stringify({"authkey": token, "key": section});

        var xhttp = new XMLHttpRequest();
        xhttp.withCredentials = false;
        xhttp.onreadystatechange = function () {
            if (this.readyState === 4 && this.status == 200) {

                if(this.responseText.includes("ddwn"))
                {
                    getIcons(this.responseText);
                }
                else
                {
                    chrome.runtime.sendMessage({
                        command: 'showdata',
                        design: JSON.parse(this.responseText),
                        icons:''
                    })
                }
            }
        };
        xhttp.open("POST", url, true);
        xhttp.setRequestHeader("Content-Type", "application/json");
        xhttp.send(data);

    } catch (err) {

    }
}

function getIcons(design) {
    try {
        var token = 'af9c88b46b3c65751a61398bd2b65076';
        var url = 'http://159.65.213.76:5055/getfonts';
        var data = JSON.stringify({"authkey": token});

        var xhttp = new XMLHttpRequest();
        xhttp.withCredentials = false;
        xhttp.onreadystatechange = function () {
            if (this.readyState === 4 && this.status == 200) {

                chrome.runtime.sendMessage({
                    command: 'showdata',
                    design: JSON.parse(design),
                    icons:JSON.parse(this.responseText)
                })
            }
        };
        xhttp.open("POST", url, true);
        xhttp.setRequestHeader("Content-Type", "application/json");
        xhttp.send(data);

    } catch (err) {

    }
}

chrome.runtime.onMessage.addListener(
    function (request, sender) {
        command = request.command;
        if (command == 'addGHLstyle') {
            addGHLstyle(request);
        } else if (command == 'getsection') {
            getDesignData(request.section);
        } 
        else if (command == 'applystyle') {
            applyStyle(request);
        } else if (command == 'GHLSettings') {
            openGHLSettings(request);
        } 
    }
);