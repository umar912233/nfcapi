let appContent = document.getElementById('appContent');
let unlicenced = document.getElementById('ult');
let emailInput = document.getElementById('emailInput');
let passwordInput = document.getElementById('passwordInput');
let errorOutput = document.getElementById('errorOutput');
let validateButton = document.getElementById('validateButton');
let addmore = document.getElementById('addMore');
let deldiv = document.getElementById('delDiv');
let create = document.getElementById('CreateTemplate');
let dash = document.getElementById('dash');
let check = document.getElementById('check-color');
let createtemp = document.getElementById('create-template');
let head = document.getElementById('head-color');

if (localStorage.getItem('email') == null) {
    $(document).find("#appContent").hide();
    $(document).find("#ult").show();
    $(document).find("#tempCreate").hide();
    console.log('not loggedin');
} else {
    validateSave();
    console.log('loggedin');
}

function validateSave() {
  console.log('working save function');
   
        validateButton.innerHTML = 'Checking...';
        validateButton.disabled = true;

    var settings = {
        "url": "http://137.184.103.200/auth",
        "method": "POST",
        "timeout": 0,
        "headers": {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        "data": {
          "email": localStorage.getItem('email')
        }
      };
      
      $.ajax(settings).done(function (response) {
        validateButton.innerHTML = 'Login';
        validateButton.disabled = false;  

        var res = JSON.parse(response);

        
        if (res.data.hasOwnProperty("email")) {
            errorOutput.innerHTML = 'Email is not valid';
          }else if(res.data.hasOwnProperty("contacts")){
            var email = res.data.contacts[0].email;
            var name = res.data.contacts[0].firstName;
            localStorage.setItem('name', name);
            localStorage.setItem('email', email);
            $(document).find("#appContent").show();
            $(document).find("#ult").hide(); 
            $(document).find("#tempCreate").hide();
            myTemplates(localStorage.getItem('email')); 
          }
      });


}

function validate() {
    var email = emailInput.value;
    if (email.length) {

        validateButton.innerHTML = 'Checking...';
        validateButton.disabled = true;

    var settings = {
        "url": "http://137.184.103.200/auth",
        "method": "POST",
        "timeout": 0,
        "headers": {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        "data": {
          "email": email
        }
      };
      
      $.ajax(settings).done(function (response) {
        validateButton.innerHTML = 'Login';
        validateButton.disabled = false;  

        var res = JSON.parse(response);

        
        if (res.data.hasOwnProperty("email")) {
            errorOutput.innerHTML = 'Email is not valid';
          }else if(res.data.hasOwnProperty("contacts")){
            var email = res.data.contacts[0].email;
            var name = res.data.contacts[0].firstName;
            localStorage.setItem('name', name);
            localStorage.setItem('email', email);
            $(document).find("#appContent").show();
            $(document).find("#ult").hide();
            $(document).find("#tempCreate").hide();
            myTemplates(email); 
          }
      });

    } else {
        errorOutput.innerHTML = 'Enter email';
    }
}

function myTemplates(email){
  var settings = {
    "url": "http://137.184.103.200/templates",
    "method": "POST",
    "timeout": 0,
    "headers": {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    "data": {
      "email": email
    }
  };
  
  $.ajax(settings).done(function (response) {
    console.log(response);
  });
}


function addMore(){
  console.log('is this working');
  // $(".cloner").clone().insertAfter(".after-one");
  $(".appender").append('<div class="col-xs-12 m-sm cloner"><div class="col-xs-5 col-md-5 col-sm-5 text-right"><input type="text" value="" class="form-control" placeholder="Location ID"></div><div class="col-xs-5 col-md-5 col-sm-5"><select id="myTemplates" class="form-control"><option>TEMPLATE 1</option><option>TEMPLATE 2</option></select></div><div class="col-xs-2 col-md-2 col-sm-2 text-right"><button class="btn btn-danger form-control" id="deldiv">DELETE</button></div></div>');
}

// function deleteDiv(){
//   console.log('this is working.........');
//   var cur = $(this);
//   cur.parent().remove();
// }

function createTemplate(){
  $(document).find("#appContent").hide();
  $(document).find("#ult").hide();
  $(document).find("#tempCreate").show();
}

function dashboardTemplate(){
  $(document).find(".dash-show").show();
}

function chekColor(){
  $(document).find("#check-color-show").slideToggle('slow');
}

function headColor(){
  $(document).find("#head-color-show").slideToggle('slow');
}

function submitTemplate(){

 var template_name = $(document).find("#template-name").val(); 
 var header_color = $(document).find("#header-color").val();
 var button_color = $(document).find("#button-color").val();

 var settings = {
  "url": "http://137.184.103.200/savetemplate",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "email": localStorage.getItem('email'),
    "header_color": header_color,
    "template_name": template_name,
    "button_color": button_color
  }
};

$.ajax(settings).done(function (response) {
  console.log(response);
});


}

validateButton.addEventListener('click', validate);
addmore.addEventListener('click', addMore);
create.addEventListener('click', createTemplate);
dash.addEventListener('click', dashboardTemplate);
check.addEventListener('click', chekColor);
head.addEventListener('click', headColor);
createtemp.addEventListener('click', submitTemplate);